// Credentials NERo
const char* ssid = "NERo-Arena";
const char* password =  "BDPsystem10";

// Credentials EFI
// const char* ssid = "NERO";
// const char* password = "BDPsystem10";

